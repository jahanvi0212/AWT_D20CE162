const mongoose = require("mongoose");
const { Schema } = mongoose;

const tblAddress = new Schema({
  addressLine1:{
    type: String,
    required: true,
},
addressLine2:{
  type: String,
  required: true,
},
city:{
  type: String,
  required: true,
},
state:{
  type: String,
  required: true,
 },
 country:{
  type: String,
  required: true,
 },
  zipCode:{
  type: Number,
  required: true,
  },
  semID: {
    type: mongoose.Schema.Types.ObjectId,
  },
});

module.exports = mongoose.model("tblAddress", tblAddress);
