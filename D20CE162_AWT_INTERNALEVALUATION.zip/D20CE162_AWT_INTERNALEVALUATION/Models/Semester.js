const mongoose = require("mongoose");
const { Schema } = mongoose;

const tblSemester = new Schema({
  title: {
    type: String,
    required: true,
  },
});

module.exports = mongoose.model("tblSemester", tblSemester);
