const mongoose = require("mongoose");
const { Schema } = mongoose;

const tblStudent = new Schema({
  studentName: {
    type: String,
    required: true,
},

email: {
    type: String,
    required: true,
},

mobileNo: {
    type: Number,
    required: true,
},
  semID: {
    type: mongoose.Schema.Types.ObjectId,
  },
});

module.exports = mongoose.model("tblStudent", tblStudent);
