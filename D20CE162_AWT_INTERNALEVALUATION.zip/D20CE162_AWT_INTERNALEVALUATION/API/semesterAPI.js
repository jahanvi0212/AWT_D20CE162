const express = require("express");
const router = express.Router();

const Semester = require("../Models/Semester");
const Address = require("../Models/Address");
const Student = require("../Models/Student");

router.post("/create", (req, res) => {
  const title = req.body.title;
  const newSemester = new Semester({
    title: title,
  });
  newSemester.save().then((sem) => res.json(sem));
});

router.get("/read", (req, res) => {
  const id = req.body.id;
  Semester.findById(id).then((sem) =>
    res.json({ messsage: "Success", sem: sem })
  );
});
router.get("/info", (req, res) => {
  const id = req.body.id;
  var address;
  var student;
  Semester.findById(id).then(async (sem) => {
    await Address.find({ semID: id }).then((sub) => (address = sub));
    await Student.find({ semID: id }).then((sub) => (student = sub));

    res.json({
      messsage: "Information",
      sem: sem,
      student: student,
      address: address,
    });
  });
});
// router.post("/update", (req, res) => {});

// router.post("/delete", (req, res) => {});

module.exports = router;
