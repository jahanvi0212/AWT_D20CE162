const express = require("express");
const router = express.Router();
const Student = require("../Models/Student");

router.post("/create", (req, res) => {
  const studentName = req.body.studentName;
  const email = req.body.email;
  const mobileNo = req.body.mobileNo;
  const semId = req.body.semId;

  const newStudent = new Student({
    studentName: studentName,
    email: email,
    mobileNo: mobileNo,
    semId: semId,
  });
  newStudent.save().then((stu) => res.json(stu));
});

router.get("/read", (req, res) => {
  const id = req.body.id;
  Subject.findById(id).then((stu) =>
    res.json({ messsage: "Success", stu: stu })
  );
});
router.post("/update", (req, res) => {});

router.post("/delete", (req, res) => {});

module.exports = router;
