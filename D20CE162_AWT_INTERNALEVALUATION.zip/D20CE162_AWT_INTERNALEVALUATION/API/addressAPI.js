const express = require("express");
const router = express.Router();
const Address = require("../Models/Address");

router.post("/create", (req, res) => {
  const addressLine1 = req.body.addressLine1;
  const addressLine2 = req.body.addressLine2;
  const city = req.body.city;
  const state = req.body.state;
  const country = req.body.country;
  const zipCode = req.body.zipCode;
  const semId = req.body.semId;


  const newAddress = new Address({
    addressLine1: addressLine1,
    addressLine2: addressLine2,
    city: city,
    state: state,
    country: country,
    zipCode: zipCode,
    semId: semId,
  });
  newAddress.save().then((addr) => res.json(addr));
});

router.get("/read", (req, res) => {
  const id = req.body.id;
  Subject.findById(id).then((addr) =>
    res.json({ messsage: "Success", addr: addr })
  );
});
router.post("/update", (req, res) => {});

router.post("/delete", (req, res) => {});

module.exports = router;

