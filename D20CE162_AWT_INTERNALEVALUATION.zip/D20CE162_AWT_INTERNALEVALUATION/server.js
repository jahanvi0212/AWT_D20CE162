const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();
const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
//Rest - APIs
const semester = require("./API/semesterAPI");
const student = require("./API/studentAPI");
const address = require("./API/addressAPI");

app.use("/semester", semester);
app.use("/student", student);
app.use("/address", address);

mongoose.connect(process.env.MONGO_URI).then((result) => {
  app.listen(process.env.PORT, () => {
    console.log("Server successfully running on ", process.env.PORT);
  });
});
