const express = require('express');
const router = express.Router();

const Controller = require('../controllers/ControllerFile');

router.get('/semester',Controller.semester);
router.get('/subject',Controller.subject);
router.get('/syllabus',Controller.syllabus);
router.post('/addSem',Controller.addSem);
router.post('/addSub',Controller.addSub);
router.post('/addSyll',Controller.addSyll);
router.post('/show',Controller.show);


module.exports = router