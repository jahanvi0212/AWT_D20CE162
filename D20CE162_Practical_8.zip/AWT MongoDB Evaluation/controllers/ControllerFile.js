const Semester = require('../models/Semester');
const Subject = require('../models/SubjectInfo');
const Syllabus = require('../models/Syllabus');

const semester = (req,res,next)=>{
    Semester.find()
    .then(response=>{
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Semester ${error}`
        })
    })
}

const subject = (req,res,next)=>{
    Subject.find()
    .then(response=>{
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Subject ${error}`
        })
    })
}

const syllabus = (req,res,next)=>{
    Syllabus.find()
    .then(response=>{
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Subject ${error}`
        })
    })
}

const addSem = (req,res,next)=>{
    let sem = new Semester({
        semID: req.body.semID,
        semester:req.body.semester
    })

    sem.save()
    .then(response=>{
        res.json({
            message:"Semester Added Successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Ocurred While Inserting Details in Semester table ${error}`
        })
    })
}

const addSub = (req,res,next)=>{
    let sub = new Subject({
        subID:req.body.subID,
        subjectCode:req.body.subjectCode,
        subjectName:req.body.subjectName,
        semID:req.body.semID
    })

    sub.save()
    .then(response=>{
        res.json({
            message:"Subject Info Added Successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Ocurred While Inserting Details in Semester table ${error}`
        })
    })
}

const addSyll = (req,res,next)=>{
    let syll = new Syllabus({
        topicID:req.body.topicID,
        topicName:req.body.topicName,
        subID:req.body.subID,
        semID:req.body.semID
    })

    syll.save()
    .then(response=>{
        res.json({
            message:"Subject Info Added Successfully"
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Ocurred While Inserting Details in Semester table ${error}`
        })
    })
}

const show = (req,res,next)=>{
    let semester = req.body.semester;
    let subject = req.body.subject;
    let subjectCode = req.body.subjectCode;

    Subject.find({subjectName:subject})
    .then(response=>{
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Ocurred ${error}`
        })
    })

    Semester.find({semester:semester})
    .then(response=>{
        console.log(response)
        var result = response
        console.log(result)
        res.json({
            response
        })
    })
    .catch(error=>{
        res.json({
            message:`Some Error Ocurred! ${error}`
        })
    })
}


module.exports = {
    semester, subject, syllabus, addSem, addSub, addSyll, show
}

