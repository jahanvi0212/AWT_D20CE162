const mongoose=require('mongoose');//exported from seperate file.


const SemesterSchema=new mongoose.Schema({
    semID:{
        type:String,
        required:true, 
    },
    semester:{
        type:Number,
        required:true
    }
});

const Semester=mongoose.model('tblSemester',SemesterSchema);

module.exports=Semester