const mongoose=require('mongoose');//exported from seperate file.
const Semester = require('./Semester');
const SubjectInfo = require('./SubjectInfo');

const SyllabusSchema=new mongoose.Schema({
    topicID:{
        type:String,
        required:true
        
    },
    topicName :{
        type:String,
        require:true
    },
    subID:{
        type:mongoose.Schema.Types.ObjectId,
        ref:SubjectInfo
    },
    semID :{
        type:mongoose.Schema.Types.ObjectId,
        ref:Semester
    }
});

const Syllabus =mongoose.model('tblSyllabus',SyllabusSchema);

module.exports=Syllabus;