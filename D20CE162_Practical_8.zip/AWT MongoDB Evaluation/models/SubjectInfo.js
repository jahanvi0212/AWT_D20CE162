const mongoose=require('mongoose');//exported from seperate file.
const Semester = require('./Semester')

const SubjectSchema=new mongoose.Schema({
    subID:{
        type:String,
        required:true
    },
    subjectCode :{
        type:String,
        require:true
    },
    subjectName:{
        type:String,
        require:true
    },
    semID :{
        type:String,
        ref:Semester
    }
});

const SubjectInfo =mongoose.model('tblSubjectInfo',SubjectSchema);

module.exports=SubjectInfo;